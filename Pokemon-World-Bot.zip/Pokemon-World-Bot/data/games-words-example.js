﻿/*
* Words for Hangman and Anagrams
*
* Rename this file to games-words.js
* Add here your topics and words in the same format as the example
*/

exports.words = {
	"Colors": ['Red', 'Orange', 'Blue', 'Yellow', 'Pink', 'Black', 'White'],
	"Days of Week": ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
};
