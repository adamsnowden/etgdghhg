﻿exports.translations = {
	commands: {
		/*
		* Youtube Commands
		*/
		youtube: {
			'notchat': 'Cette commande est avaliable seulement pour les salles de chat',
			'u': 'Usage',
			'ae': 'La reconnaissance YouTube est déjà disponible pour la salle',
			'e': 'La reconnaissance de lien YouTube est  maintenant disponible pour cette salle',
			'ad': 'La reconnaissance de lien YouTube est  déjà désactivé pour la salle',
			'd': 'La reconnaissance de lien YouTube  est  maintenant désactivée pour cette salle'
		}
	},

	youtube: {
		'before': 'Le lien de',
		'after': ''
	}
};
