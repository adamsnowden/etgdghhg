﻿exports.translations = {
	commands: {
		/*
		* Youtube Commands
		*/
		youtube: {
			'notchat': 'Questo comando è disponibile solo nelle chat rooms',
			'u': 'Usage',
			'ae': 'Il riconoscimento dei link YouTube è già abilitato',
			'e': 'Il riconoscimento dei link YouTube è ora abilitato',
			'ad': 'Il riconoscimento dei link YouTube è già disabilitato',
			'd': 'Il riconoscimento dei link YouTube è ora disabilitato'
		}
	},

	youtube: {
		'before': '',
		'after': 'link di'
	}
};
