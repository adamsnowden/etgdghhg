exports.server = 'sim.psim.online';

exports.port = 8000;

exports.serverid = 'showdown';

exports.nick = 'Example Bot name';

exports.pass = 'ExamplePassword';